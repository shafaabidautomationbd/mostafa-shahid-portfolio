# Md. Mostafa Shahid — Engineering Portfolio

A static portfolio website built with HTML, CSS and vanilla JavaScript for GitHub + Cloudflare Pages.

## Files
- `index.html` — portfolio sections and modal markup
- `styles.css` — responsive styling
- `script.js` — interactive skill buttons and project details
- `reports/` — the three supplied KSRM EMS achievement reports

## Preview locally
Open `index.html` in a browser. For best results, use a local static server such as VS Code Live Server.

## Deploy with GitHub + Cloudflare Pages
1. Create a new GitHub repository named `mostafa-shahid-portfolio`.
2. Upload the contents of this folder (make sure `index.html` is at repository root) and commit to `main`.
3. In Cloudflare, open Workers & Pages → Create application → Pages → Connect to Git.
4. Select the repository. Framework preset: `None`; Build command: `exit 0`; Build output directory: `/` (or leave as the root directory if the UI accepts it).
5. Deploy. Cloudflare will provide a `*.pages.dev` URL. Connect a custom subdomain only after reviewing the public content and confirming the employer permits publishing the reports.

## Before public launch
- Review the CV details and add any missing training/certifications and technical projects.
- Confirm permission to publish the KSRM reports and any plant screenshots.
- Replace or supplement generic project visuals with approved screenshots from your own projects.
- Confirm contact details and public-facing personal information.
